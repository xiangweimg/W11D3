function Movies() {
  return (
    <div className="comp orange">
      <h1>Movies Component</h1>
    </div>
  );
}

export default Movies;
